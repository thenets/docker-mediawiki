<?php

class EchoEmailFrequency {
	const NEVER = -1; // Never send email notifications
	const IMMEDIATELY = 0; // Send email notifications immediately as they come in
	const DAILY_DIGEST = 1; // Send daily email digests
	const WEEKLY_DIGEST = 7; // Send weekly email digests
}
