# Usage

    vagrant up
    vagrant roles enable echo flow wikimediaflow
    vagrant provision
    bundle install
    bundle exec rake spec
