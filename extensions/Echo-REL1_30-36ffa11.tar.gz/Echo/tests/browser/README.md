Please see https://github.com/wikimedia/mediawiki-selenium for instructions on how to run tests.
