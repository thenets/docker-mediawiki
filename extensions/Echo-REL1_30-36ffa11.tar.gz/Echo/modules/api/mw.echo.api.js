( function ( mw ) {
	mw.echo = mw.echo || {};
	mw.echo.api = mw.echo.api || {};
}( mediaWiki ) );
