( function ( mw, $ ) {
	mw.echo = mw.echo || {};
	mw.echo.ui = {
		$overlay: $( '<div>' )
			.addClass( 'mw-echo-ui-overlay' )
	};
}( mediaWiki, jQuery ) );
