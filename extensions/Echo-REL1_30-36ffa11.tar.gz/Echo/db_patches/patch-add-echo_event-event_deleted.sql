ALTER TABLE /*_*/echo_event ADD COLUMN event_deleted tinyint unsigned NOT NULL DEFAULT 0;
