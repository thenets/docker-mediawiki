CREATE INDEX /*i*/echo_notification_event ON /*_*/echo_notification (notification_event);
