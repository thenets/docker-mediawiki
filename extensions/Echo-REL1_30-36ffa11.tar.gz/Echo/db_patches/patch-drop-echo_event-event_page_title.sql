-- Patch to drop unused event_page_title
alter table /*_*/echo_event drop event_page_title;

