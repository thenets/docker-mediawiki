class MainPage
  include PageObject

  page_url 'Main_Page'
end
