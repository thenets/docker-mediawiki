/*!
 * VisualEditor Wikitext sequence registry
 *
 * This should probably never have anything in it.
 *
 * @copyright 2011-2018 VisualEditor Team and others; see http://ve.mit-license.org
 */

/* Initialization */

ve.ui.wikitextSequenceRegistry = new ve.ui.SequenceRegistry();
